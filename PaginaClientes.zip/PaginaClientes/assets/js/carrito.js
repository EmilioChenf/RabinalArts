class Carrito {
    comprarProducto(e) {
        e.preventDefault();
        if (e.target.classList.contains('agregar-carrito')) {
            const producto = e.target.parentElement;
            this.leerDatosProducto(producto);
        }
    }

    leerDatosProducto(producto) {
        const cantidadElemento = producto.querySelector('.cantidad-input');
        const cantidad = cantidadElemento ? parseInt(cantidadElemento.value) : 1;
    
        const idElemento = producto.querySelector('.agregar-carrito');
        const id = idElemento ? idElemento.getAttribute('data-id') : null;
    
        if (!id) {
            console.error("Error: No se encontró el ID del producto.");
            return;
        }
    
        // Asegurar que el precio sea un número antes de guardarlo
        let precioNumerico = parseFloat(producto.querySelector('.precio').textContent);
        if (isNaN(precioNumerico)) {
            console.error("Error: Precio inválido en producto", producto);
            precioNumerico = 0;
        }
    
        const infoProducto = {
            imagen: producto.querySelector('img').src,
            titulo: producto.querySelector('h5').textContent,
            precio: precioNumerico, // Guardar el precio como número
            id: id,
            cantidad: cantidad
        };
    
        let productosLS = this.obtenerProductosLocalStorage();
    
        let index = productosLS.findIndex(p => p.id === infoProducto.id);
    
        if (index !== -1) {
            productosLS[index].cantidad += cantidad;
        } else {
            productosLS.push(infoProducto);
        }
    
        this.guardarProductosLocalStorage(productosLS);
        this.insertarCarrito(infoProducto);
    
        Swal.fire({
            icon: 'success',
            title: 'Producto agregado al carrito',
            timer: 2000,
            showConfirmButton: false
        });
    }
    

    guardarProductosLocalStorage(productos) {
        localStorage.setItem('productos', JSON.stringify(productos));
    }

    obtenerProductosLocalStorage() {
        return JSON.parse(localStorage.getItem('productos')) || [];
    }
}

// Instancia global para que otros archivos puedan usarla
const carrito = new Carrito();


// Correcciones en carrito.js para evitar errores en el DOM
document.addEventListener('DOMContentLoaded', function () {
    cargarEventos();
    leerLocalStorageCompra();
});

// ✅ Captura eventos de todos los botones dentro de la tabla del carrito
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('btn-incrementar')) {
        let input = e.target.previousElementSibling;
        if (input) {
            input.value = parseInt(input.value) + 1;
            actualizarCantidad(input);
        }
    } else if (e.target.classList.contains('btn-decrementar')) {
        let input = e.target.nextElementSibling;
        if (input && parseInt(input.value) > 1) {
            input.value = parseInt(input.value) - 1;
            actualizarCantidad(input);
        }
    } else if (e.target.classList.contains('borrar-producto')) {
        let id = e.target.getAttribute('data-id');
        if (id) eliminarProducto(id, e.target);
    }
});

// ✅ Función para eliminar un producto del carrito
function eliminarProducto(id, btn) {
    let productosLS = JSON.parse(localStorage.getItem('productos')) || [];
    
    // Filtra los productos para remover el seleccionado
    productosLS = productosLS.filter(producto => producto.id !== id);
    
    // Guarda los productos actualizados en localStorage
    localStorage.setItem('productos', JSON.stringify(productosLS));

    // Elimina el producto del DOM
    let row = btn.closest('tr');
    if (row) {
        row.remove();
    }

    calcularTotal(); // Recalcular el total después de eliminar un producto
}


// ✅ Función para actualizar la cantidad y recalcular el subtotal
function actualizarCantidad(input) {
    let row = input.closest('tr');
    if (!row) {
        console.error("Error: No se encontró la fila del producto.");
        return;
    }

    let id = row.dataset.id;
    let productosLS = JSON.parse(localStorage.getItem('productos')) || [];
    let producto = productosLS.find(p => p.id === id);

    if (producto) {
        producto.cantidad = parseInt(input.value);
        localStorage.setItem('productos', JSON.stringify(productosLS));

        let subtotalElement = row.querySelector('.subtotal');
        if (subtotalElement) {
            subtotalElement.textContent = (producto.precio * producto.cantidad).toFixed(2);
        }

        calcularTotal();
    } else {
        console.error("Error: No se encontró el producto en LocalStorage.");
    }
}

// ✅ Función para calcular el total correctamente
function calcularTotal() {
    let productosLS = JSON.parse(localStorage.getItem('productos')) || [];
    let total = productosLS.reduce((sum, producto) => sum + (producto.precio * producto.cantidad), 0);

    let subtotalElement = document.getElementById('subtotal');
    let igvElement = document.getElementById('igv');
    let totalElement = document.getElementById('total');

    if (subtotalElement) subtotalElement.innerHTML = "S/. " + (total / 1.18).toFixed(2);
    if (igvElement) igvElement.innerHTML = "S/. " + (total * 0.18).toFixed(2);
    if (totalElement) totalElement.value = "S/. " + total.toFixed(2);
}

function cargarEventos() {
    let procesarCompraBtn = document.getElementById('procesar-compra');
    
    if (procesarCompraBtn) {
        procesarCompraBtn.addEventListener('click', procesarPedido);
    } else {
        console.warn("El botón 'procesar-compra' no fue encontrado en el DOM.");
    }
}

function leerLocalStorageCompra() {
    let productosLS = JSON.parse(localStorage.getItem('productos')) || [];
    let listaCompra = document.querySelector('#lista-compra tbody');

    if (!listaCompra) {
        console.error("Error: No se encontró la tabla del carrito en el DOM.");
        return;
    }

    listaCompra.innerHTML = '';

    if (productosLS.length === 0) {
        console.warn("No hay productos en el carrito.");
        return;
    }

    productosLS.forEach(producto => {
        if (!producto || !producto.id || !producto.titulo) {
            console.error("Producto inválido:", producto);
            return;
        }

        // Convertir el precio a número antes de usar .toFixed(2)
        let precioNumerico = parseFloat(producto.precio);
        if (isNaN(precioNumerico)) {
            console.error("Error: Precio inválido en producto", producto);
            precioNumerico = 0; // Si hay un error, poner precio en 0 para evitar fallos.
        }

        let cantidadNumerica = parseInt(producto.cantidad) || 1; 

        const row = document.createElement('tr');
        row.dataset.id = producto.id;
        row.innerHTML = `
            <td><img src="${producto.imagen}" width=100></td>
            <td>${producto.titulo}</td>
            <td>S/.${precioNumerico.toFixed(2)}</td>
            <td>
                <button class="btn-decrementar">-</button>
                <input type="number" class="cantidad-carrito" value="${cantidadNumerica}" min="1">
                <button class="btn-incrementar">+</button>
            </td>
            <td>S/.<span class="subtotal">${(precioNumerico * cantidadNumerica).toFixed(2)}</span></td>
            <td>
                <button class="borrar-producto" data-id="${producto.id}">🗑️</button>
            </td>
        `;

        listaCompra.appendChild(row);
    });

    calcularTotal();
}


function procesarPedido(e) {
    e.preventDefault();
    
    let productosLS = JSON.parse(localStorage.getItem('productos')) || [];
    if (productosLS.length === 0) {
        Swal.fire({
            icon: 'error',
            title: 'El carrito está vacío, agrega un producto',
            timer: 2500,
            showConfirmButton: false
        });
    } else {
        window.location.href = "carrito.html";
    }
}

